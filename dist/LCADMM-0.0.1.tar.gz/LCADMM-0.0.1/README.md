# LCADMM
Prox-JADMM algorithm for linear constrained optimization

This package solves a decentralized optimization problem with coupling linear inequality constraints. The objective is to minimize the local objective functions and the violation of the coupling inequality constraints.

The package comes with an example showcasing the basic functions.
